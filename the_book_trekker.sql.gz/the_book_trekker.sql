-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2023 at 11:21 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `the book trekker`
--

-- --------------------------------------------------------

--
-- Table structure for table `contribution`
--

CREATE TABLE `contribution` (
  `booktitle` text NOT NULL,
  `author` text NOT NULL,
  `type` text NOT NULL,
  `genre` text NOT NULL,
  `name` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `feedback` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contribution`
--

INSERT INTO `contribution` (`booktitle`, `author`, `type`, `genre`, `name`, `email`, `feedback`) VALUES
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'i loved it\r\n'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'i loved it\r\n'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'i loved it\r\n'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'i loved it\r\n'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'i loved it\r\n'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'i loved it\r\n'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'i loved it\r\n'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'i loved it'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'smnadjksh'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'd,dfnuiewbtuj'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'd,dfnuiewbtuj'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'd,dfnuiewbtuj'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'd,dfnuiewbtuj'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'd,dfnuiewbtuj'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'd,dfnuiewbtuj'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'd,dfnuiewbtuj'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'i loved it'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'i loved it'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'i loved it'),
('harry potter', 'J.K Rowlings', '', 'fiction', 'Aashruti Patolia', 'lisa.forget.uta@gmail.com', 'kasnfkuesdgbg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
